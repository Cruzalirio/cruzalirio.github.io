library(gee)
library(xtable)
library(readxl)
library(tidyverse)
library(ggcorrplot)
library(corrplot)
library(geepack)
library(MASS)
source("~/Doctorado/SegundoArticulo/Sim_general_CrosKron.R")

source("~/Doctorado/SegundoArticulo/Estimacion_funciones.R")

Datos_con_base <- read_excel("Doctorado/Datos_vacas.xlsx")
library(nlme)
Datos_con_base=Datos_con_base[order(Datos_con_base$Sujeto,
                                    Datos_con_base$Periodo, Datos_con_base$Tiempo), ]
Datos_con_base$Base=Datos_con_base$prod+Datos_con_base$dprod

Datos_con_base["Per_id"]=as.numeric(
  as.factor(paste(Datos_con_base$Sujeto, Datos_con_base$Periodo)))


dat=groupedData(prod~Tiempo|Sujeto, data=Datos_con_base, inner=~Tratamiento)
plot(dat, inner = T)
formula=dprod~factor(Periodo)+Tratamiento+I(Tiempo^2)+Tiempo*Carryover_control

datos = Datos_con_base %>% data.frame()
datos["resp"] = datos$dprod

init=gee(formula,
         data=datos, id=Sujeto, corstr = "AR-M")
pp <- length(init$coefficients)
#resid <- init$residuals/sqrt(init$fitted.values-init$fitted.values^2)
resid <- init$residuals
phi <- sum(resid^2)/(length(resid)-pp)

init

Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(resid, datos, tipo="Exch"))

matrices <- obtPsi(resid, datos, Ralpha )

corrplot(kronecker(matrices$Psi, matrices$Ra))


Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(resid, datos, tipo="Exch"))
RR <- kronecker(matrices$Psi, matrices$Ra)
beta_init <- init$coefficients

n_iter = 20
diferencia <- numeric(n_iter)
for(iter in 1:n_iter){
  modelo = gee(formula,
               data=datos, id=Sujeto, corstr = "fixed",
               R = RR, b = beta_init, maxiter = 1, tol=100)
  diferencia[iter] = sum((beta_init-modelo$coefficients)^2)
  beta_init = modelo$coefficients
  pp=2
  #resid <- modelo$residuals/sqrt(modelo$fitted.values-modelo$fitted.values^2)
  resid <- modelo$residuals
  phi <- sum(resid^2)/(length(resid)-pp)
  matrices <- obtPsi(resid, datos, Ralpha )
  Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(resid, datos, tipo="Exch"))
  RR <- kronecker(matrices$Psi, matrices$Ra)
}


plot(diferencia)
summary(modelo)


modelo1 = gee(formula,
              data=datos, id=Sujeto, corstr = "exchangeable")

summary(modelo1)


corrplot(modelo1$working.correlation)
corrplot(modelo$working.correlation)




mod1=gee(formula,data=datos, id=Per_id,corstr="independence")
mod2=gee(formula,data=datos, id=Per_id,corstr="AR-M")
mod3=gee(formula,data=datos, id=Sujeto,corstr="AR-M")
mod4=gee(formula,data=datos, id=Sujeto,corstr="exchangeable")
mod5=gee(formula,data=datos, id=Sujeto,corstr="fixed",R =RR)

QIC=numeric(5)

QIC[1]<-sum((mod1$residuals)^2)+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod1$naive.variance))
QIC[2]<-sum((mod2$residuals)^2)+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod2$robust.variance))
QIC[3]<-sum((mod3$residuals)^2)+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod3$robust.variance))
QIC[4]<-sum((mod4$residuals)^2)+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod4$robust.variance))
QIC[5]<-sum((mod5$residuals)^2)+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod5$robust.variance))


QIC


summary(modelo)
