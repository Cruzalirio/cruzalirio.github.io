rm(list=ls())

library(data.table)
library(MASS)
library(stats)
library(tidyverse)
library(gee)
setwd("~/Doctorado/SegundoArticulo/pone.0232943.s001/data")
# GLMs of perception based variables

#Load data
anasurv <- fread("./cleansurvey.csv")

# Environmental variables

env <- fread( "./sensor_readings.csv")

# Commits
commits <- fread("./git_commits.csv")


# Occupancy data
occ <- fread("./desk_occupancy.csv")

occup_hora <- occ %>% group_by(area, wave, hours, sensor, prev_wave) %>%
  summarise(n=n(), n_occup=sum(reading)) %>% arrange(sensor, wave) %>% 
  mutate(prop = n_occup/n, sensorid = as.numeric(as.factor(sensor)))  




#### Modelo con GLMM

load(file="/content/Hora.RData")
occup_hora["Per_id"]= as.numeric(
  as.factor(paste(occup_hora$sensorid, occup_hora$wave)))
datos = occup_hora

formula = cbind(n_occup, n-n_occup) ~area+wave+factor(hours)+prev_wave


mod1 = gee(formula, family= binomial,
           data=datos, id=Per_id)

mod2 = gee(formula, family= binomial,
           data=datos, id=sensorid)

mod3 = gee(formula, family= binomial,
           data=datos, id=sensorid, corstr = "exchangeable")

mod4 = gee(formula, family= binomial,
           data=datos, id=Per_id, corstr = "AR-M")



init=gee(formula, family= binomial,
         data=datos, id=sensorid)
pp <- length(init$coefficients)
residu <- init$residuals/sqrt(init$fitted.values-init$fitted.values^2)
#residu <- init$residuals
phi <- sum(residu^2)/(length(residu)-pp)


Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Exch"))
matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
RR <- kronecker(matrices$Psi, matrices$Ra)
if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
  RR = diag(1,nrow(RR))
  beep(7)
}
beta_init <- init$coefficients
n_iter = 4
diferencia <- numeric(n_iter)
for(iter in 1:n_iter){
  modelo = gee(formula, family= binomial,
               data=datos, id=sensorid, corstr = "fixed",
               R = RR, b = beta_init, maxiter = 1, tol=100)
  diferencia[iter] = sum((beta_init-modelo$coefficients)^2)
  beta_init = modelo$coefficients
  residu <- modelo$residuals/sqrt(modelo$fitted.values-modelo$fitted.values^2)
  #residu <- modelo$residuals
  phi <- sum(residu^2)/(length(residu)-pp)
  Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Exch"))
  matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
  RR <- kronecker(matrices$Psi, matrices$Ra)
  if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
    RR = diag(1,nrow(RR))
    beep(7)
  }
}

mod5 = modelo


## El AR 1
init=gee(formula, family= binomial,
         data=datos, id=sensorid)
pp <- length(init$coefficients)
residu <- init$residuals/sqrt(init$fitted.values-init$fitted.values^2)
#residu <- init$residuals
phi <- sum(residu^2)/(length(residu)-pp)

Ralpha = Ar1(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Ar1"))
matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
RR <- kronecker(matrices$Psi, matrices$Ra)
if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
  RR = diag(1,nrow(RR))
  beep(7)
}
beta_init <- init$coefficients
n_iter = 4
diferencia <- numeric(n_iter)
for(iter in 1:n_iter){
  modelo = gee(formula, family= binomial,
               data=datos, id=sensorid, corstr = "fixed",
               R = RR, b = beta_init, maxiter = 1, tol=100)
  diferencia[iter] = sum((beta_init-modelo$coefficients)^2)
  beta_init = modelo$coefficients
  residu <- modelo$residuals/sqrt(modelo$fitted.values-modelo$fitted.values^2)
  #residu <- modelo$residuals
  phi <- sum(residu^2)/(length(residu)-pp)
  Ralpha = Ar1(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Ar1"))
  matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
  RR <- kronecker(matrices$Psi, matrices$Ra)
  if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
    RR = diag(1,nrow(RR))
    beep(7)
  }
}
mod6 = modelo


QIC=numeric(6)

QIC[1]<--2*sum(mod1$y * log(mod1$fitted.values/(1-mod1$fitted.values))+log(1-mod1$fitted.values))+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod1$naive.variance))
QIC[2]<--2*sum(mod2$y * log(mod2$fitted.values/(1-mod2$fitted.values))+log(1-mod2$fitted.values))+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod2$robust.variance))
QIC[3]<--2*sum(mod3$y * log(mod3$fitted.values/(1-mod3$fitted.values))+log(1-mod3$fitted.values))+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod3$robust.variance))
QIC[4]<--2*sum(mod4$y * log(mod4$fitted.values/(1-mod4$fitted.values))+log(1-mod4$fitted.values))+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod4$robust.variance))
QIC[5]<--2*sum(mod5$y * log(mod5$fitted.values/(1-mod5$fitted.values))+log(1-mod5$fitted.values))+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod5$robust.variance))
QIC[6]<--2*sum(mod6$y * log(mod6$fitted.values/(1-mod6$fitted.values))+log(1-mod6$fitted.values))+
  2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod6$robust.variance))


