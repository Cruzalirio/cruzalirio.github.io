####################################

library(gee)
library(MASS)
library(SimDesign)

library(SimCorMultRes)

####################################
##### Parameters ###################
####################################

#### Simulated a unstructured #####
### corr matrix  psi  #############



SinEstructura <- function(nperiod=3){
  psi_m = matrix(0, nrow=nperiod, ncol=nperiod)
  condicion = TRUE
  while(condicion == TRUE){
    for(i in 1:nperiod){
      for(j in i:nperiod){
        a = runif(1, -0.4,0.8)
        psi_m[i,j]= a
        psi_m[j,i] = a
      }
    }
    diag(psi_m)=1
    condicion = min(eigen(psi_m)$values)<0
  }
  return(psi_m)
}

SinEstructura(5)

###############################
####### Una intercambiable ###

Intercam <- function(ntimes=10, alpha=0.5){
  psi_m = toeplitz(c(1, rep(alpha, ntimes-1)))
  return(psi_m)
}

Intercam(10,0.5)

###################
## AR1 ##############
Ar1 <- function(ntimes=10, alpha=0.5){
  psi_m = matrix(0, nrow=ntimes, ncol=ntimes)
  for(i in 1:ntimes){
    for(j in 1:ntimes){
      psi_m[i,j]=alpha^(abs(i-j))
    }
  }
  return(psi_m)
}

Ar1(10,-0.9)

##################################
#### Simular una normal ##########
##################################
Sim_Norm_Kron <- function(nperiod, ntimes, nseq, nind, corst =c("Exch", "Ar1", "Unst"), alpha=0.5,
                          betas_p = NULL, betas_T = NULL,tratamiento=1, 
                          disenno= c("2x2", "PE", "SB"), intercepto = 2){
  P = nperiod
  L = ntimes
  if(corst == "Exch"){
    RR = kronecker(SinEstructura(nperiod), Intercam(ntimes, alpha))
  }else if (corst == "Ar1") {
    RR = kronecker(SinEstructura(nperiod), Ar1(ntimes, alpha))
  }else{RR = kronecker(SinEstructura(nperiod), SinEstructura(ntimes)) }
  ## Periodo
  if(is.null(betas_p)){
    p_eff=rnorm(P-1)
  }else{p_eff = betas_p}
  ### Tratamiento
  if(is.null(betas_T)){
    time_effect=rnorm(L-1)
  }else{time_effect = betas_T}
  ## Secuencia
  periodo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                    kronecker(matrix(1:P, ncol=1, nrow=P), 
                              matrix(1, ncol=1, nrow=L)))
  
  tiempo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                   kronecker(matrix(1, ncol=1, nrow=P), 
                             matrix(1:L, ncol=1, nrow=L)))
  secuencia=kronecker(matrix(1:nseq, ncol=1, nrow = nseq), 
                      kronecker(matrix(1, ncol=1, nrow=P*nind), 
                                matrix(1, ncol=1, nrow=L)))
  id=as.numeric(gl(nind*nseq,nperiod*ntimes))
  datos=numeric(nind*nseq*nperiod*ntimes)
  df=data.frame(resp=datos, Periodo=factor(periodo),Secuencia=factor(secuencia),
                Tiempo=factor(tiempo), Sujeto=id )
  df=df[order(df$Sujeto,df$Periodo, df$Tiempo), ]
  ### Estructura del tratamiento
  
  df["Tratamiento"]=0
  if(disenno=="2x2"){
    ## AB, BA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else if(disenno =="PE") {
    ## ABB, BAA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else{
    ## ABA, BAB
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1 
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==3] =1
  }
  
  XX = model.matrix(lm(resp~factor(Periodo)+ factor(Tratamiento)+factor(Tiempo), data=df))
  beta_total = c(intercepto, p_eff, tratamiento, time_effect)
  df["media"]= XX%*%beta_total
  
  for(i in 1:(nind*nseq)){
    df["resp"][df["Sujeto"]==i] = rmvnorm(1, df["media"][df["Sujeto"]==i], RR)
  }
  return(list(datos=df, corr=RR))
}


### Simular binomiales ###
### Basado en 
# https://cran.r-project.org/web/packages/SimCorMultRes/vignettes/SimCorMultRes.html
####################



Sim_Bin_Kron <- function(nperiod, ntimes, nseq, nind, corst =c("Exch", "Ar1", "Unst"), alpha=0.5,
                         betas_p = NULL, betas_T = NULL,tratamiento=1, 
                         disenno= c("2x2", "PE", "SB"), intercepto = 2){
  P = nperiod
  L = ntimes
  if(corst == "Exch"){
    RR = kronecker(SinEstructura(nperiod), Intercam(ntimes, alpha))
  }else if (corst == "Ar1") {
    RR = kronecker(SinEstructura(nperiod), Ar1(ntimes, alpha))
  }else{RR = kronecker(SinEstructura(nperiod), SinEstructura(ntimes)) }
  ## Periodo
  if(is.null(betas_p)){
    p_eff=abs(rnorm(P-1,sd = 0.1))
  }else{p_eff = betas_p}
  ### Tratamiento
  if(is.null(betas_T)){
    time_effect=rnorm(L-1)
  }else{time_effect = betas_T}
  ## Secuencia
  periodo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                    kronecker(matrix(1:P, ncol=1, nrow=P), 
                              matrix(1, ncol=1, nrow=L)))
  
  tiempo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                   kronecker(matrix(1, ncol=1, nrow=P), 
                             matrix(1:L, ncol=1, nrow=L)))
  secuencia=kronecker(matrix(1:nseq, ncol=1, nrow = nseq), 
                      kronecker(matrix(1, ncol=1, nrow=P*nind), 
                                matrix(1, ncol=1, nrow=L)))
  id=as.numeric(gl(nind*nseq,nperiod*ntimes))
  datos=numeric(nind*nseq*nperiod*ntimes)
  df=data.frame(resp=datos, Periodo=factor(periodo),Secuencia=factor(secuencia),
                Tiempo=factor(tiempo), Sujeto=id )
  df=df[order(df$Sujeto,df$Periodo, df$Tiempo), ]
  ### Estructura del tratamiento
  
  df["Tratamiento"]=0
  if(disenno=="2x2"){
    ## AB, BA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else if(disenno =="PE") {
    ## ABB, BAA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else{
    ## ABA, BAB
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1 
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==3] =1
  }
  XX = model.matrix(lm(resp~Periodo+Tratamiento+Tiempo, data=df))
  beta_total = c(intercepto, p_eff, tratamiento, time_effect)
  df["media"]= XX%*%beta_total
  form <- formula(lm(`(Intercept)`~., data=as.data.frame(XX)))
  df1 <- rbin(clsize = nperiod*ntimes,intercepts = intercepto, betas=beta_total[-1],
              xformula =form[c(1,3)],
              xdata= XX[,-1],
              cor.matrix = RR, link="logit")
  df["resp"] <- df1$simdata$y  
  return(list(datos=df, corr=RR))
}


## Binomiales
datos <- Sim_Bin_Kron(nperiod = 3, ntimes=10, nseq=2, nind =15, corst = "Ar1", alpha = 0.2, disenno = "PE")

## normales
datos <- Sim_Norm_Kron(nperiod = 3, ntimes=5, nseq=2, nind =15, corst = "Ar1", alpha = 0.2, disenno = "PE")





## residuuales
## https://www.sfu.ca/sasdoc/sashtml/stat/chap29/sect38.htm

simulacion <- Sim_Bin_Kron(nperiod = 3, ntimes=10, nseq=2, nind =15, corst = "Ar1", 
                           alpha = 0.8, disenno = "PE", tratamiento = -2, intercepto = 1, 
                           betas_p = runif(2,0.2, 0.3), betas_T = rep(0,9))


##### son tres pasos
## Estimar beta con un R_alpha dado
## Estimar alpha dentro con GEE
### estimar Psi con lo anterior
### Actualizar y repetir
### binomial

obtalpha <- function(residu, datos, tipo=c("Ar1", "Exch")){
  if(tipo=="Ar1"){
    K1 = sum(table(datos$Per_id)-1)
    n = length(table(datos$Per_id))
    suma=0
    for(i in 1:n){
      residu_temp = residu[datos$Per_id==i]
      n_temp =length(residu_temp)
      suma = suma + sum(residu_temp[-n_temp]*residu_temp[-1])
    }
    alpha = suma/((K1-pp)*phi)
  }else if(tipo=="Exch"){
    K1 =sum((table(datos$Per_id)-1)*(table(datos$Per_id)))
    n = length(table(datos$Per_id))
    suma=0
    for(i in 1:n){
      residu_temp = residu[datos$Per_id==i]
      a_temp = outer(residu_temp, residu_temp)
      suma = suma + sum(a_temp[lower.tri(a_temp)])
    }
    alpha = suma/((K1-pp)*phi)
  }
  return(alpha)
}


############################
## obtener Psi #############

obtPsi <- function(residu, datos, Ralpha){
  datos["residu"] <- residu
  PP <- length(table(datos$Periodo))
  LL <- max(table(datos$Per_id))
  n_suj <- length(table(datos$Sujeto))
  Psi <- matrix(0, PP, PP)
  ### las medias por periodo
  r_media <- matrix(0, PP, LL)
  for(ii in 1:PP){
    media_temp = rep(0, LL)
    datos_temp = datos[datos$Periodo==ii,]
    for(jj in 1:n_suj){
      media_temp = media_temp + datos_temp[datos_temp$Sujeto==jj, "residu"]
    }
    r_media[ii,] <- media_temp/(n_suj)
  }
  ###### cada Psi
  for(ii in 1:PP){
    for(jj in 1:PP){
      suma_temp = 0
      for( kk in 1:n_suj){
        datos_temp1 = datos[datos$Periodo==ii,]
        datos_temp2 = datos[datos$Periodo==jj,]
        residu1 = datos_temp1[datos_temp1$Sujeto==kk, "residu"]
        residu2 = datos_temp2[datos_temp2$Sujeto==kk, "residu"]
        AAA = solve(Ralpha) %*%((residu1- r_media[ii,])%*% t((residu2- r_media[jj,])))
        suma_temp  = suma_temp  + sum(diag(AAA))
      }
      Psi[ii,jj] = suma_temp /n_suj
    }
  }
  a=Psi
  return(list(Psi=(diag(1/sqrt(diag(a))))%*% a %*% (diag(1/sqrt(diag(a)))), Ra = Ralpha, Psi1=Psi))
}


### 
simulacion <- Sim_Norm_Kron(nperiod = 3, ntimes=5, nseq=2, nind =100, corst ="Exch", 
                            alpha = 0.8, disenno = "PE", tratamiento = -2, intercepto = 1, 
                            betas_p = runif(2,0.2, 0.3), betas_T = rep(0,4))

datos = simulacion$datos
datos["Per_id"]=as.numeric(
  as.factor(paste(datos$Sujeto, datos$Periodo)))

formula = resp ~ factor(Periodo)+ Tratamiento
corrplot(simulacion$corr)

init=gee(formula,
         data=datos, id=Sujeto)
pp <- length(init$coefficients)
#residu <- init$residuuals/sqrt(init$fitted.values-init$fitted.values^2)
residu <- init$residuals
phi <- sum(residu^2)/(length(residu)-pp)


Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Ar1"))
matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
RR <- kronecker(matrices$Psi, matrices$Ra)
beta_init <- init$coefficients
n_iter = 4
diferencia <- numeric(n_iter)
for(iter in 1:n_iter){
  modelo = gee(formula,
               data=datos, id=Sujeto, corstr = "fixed",
               R = RR, b = beta_init, maxiter = 1, tol=100)
  diferencia[iter] = sum((beta_init-modelo$coefficients)^2)
  beta_init = modelo$coefficients
  #residu <- modelo$residuuals/sqrt(modelo$fitted.values-modelo$fitted.values^2)
  residu <- modelo$residuals
  phi <- sum(residu^2)/(length(residu)-pp)
  Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Ar1"))
  matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
  RR <- kronecker(matrices$Psi, matrices$Ra)
  if(is.complex(eigen(RR)$values)){
    RR = diag(1,nrow(RR))
    beep(7)
  }
}
plot(diferencia)

corrplot(RR)
corrplot(simulacion$corr)


round(RR,3)
round(simulacion$corr,3)


################################################
## Estudio sobre las veces que el QIC gana #####
################################################
rm(list=ls())

library(gee)
library(geepack)

library(beepr)

library(gee)
library(MASS)
library(SimDesign)

library(SimCorMultRes)




nind = c(5,10,20, 50, 100)
alpha = seq(0, 0.9, 0.2)
tratamiento = seq(0,1.5,0.25)
carry =  seq(0,1.5,0.25)
Matriz_sim = c("Exch", "Ar1")
ntimes = c(2,5,10,15)

modelos=character()
QIC_obt = numeric()
alphas = numeric()
tratam = numeric()
carryB = numeric()
indiv = numeric()
estim_t = numeric()
estim_c = numeric()
times = numeric()
p_valor_t = numeric()
p_valor_c = numeric()
rmse_t = numeric()
rmse_c = numeric()
mat_sim = character()
mat_adj = character()
repet = numeric()


####################################
##### Parameters ###################
####################################

#### Simulated a unstructured #####
### corr matrix  psi  #############



SinEstructura <- function(nperiod=3){
  psi_m = matrix(0, nrow=nperiod, ncol=nperiod)
  condicion = TRUE
  while(condicion == TRUE){
    for(i in 1:nperiod){
      for(j in i:nperiod){
        a = sample(c(0, 0.3, 0.4, 0.5, 
                     0.6, 0.65, 0.7, 0.75, 0.8, 0.8, 0.8),1)
        psi_m[i,j]= a
        psi_m[j,i] = a
      }
    }
    diag(psi_m)=1
    condicion = min(eigen(psi_m)$values)<0
  }
  return(psi_m)
}


###############################
####### Una intercambiable ###

Intercam <- function(ntimes=10, alpha=0.5){
  psi_m = toeplitz(c(1, rep(alpha, ntimes-1)))
  return(psi_m)
}

Intercam(10,0.5)

###################
## AR1 ##############
Ar1 <- function(ntimes=10, alpha=0.5){
  psi_m = matrix(0, nrow=ntimes, ncol=ntimes)
  for(i in 1:ntimes){
    for(j in 1:ntimes){
      psi_m[i,j]=alpha^(abs(i-j))
    }
  }
  return(psi_m)
}


##################################
#### Simular una normal ##########
##################################
Sim_Norm_Kron <- function(nperiod, ntimes, nseq, nind, corst =c("Exch", "Ar1", "Unst"), alpha=0.5,
                          betas_p = NULL, betas_T = NULL,tratamiento=1, carry=0.5, 
                          disenno= c("2x2", "PE", "SB"), intercepto = 2){
  P = nperiod
  L = ntimes
  if(corst == "Exch"){
    RR = kronecker(SinEstructura(nperiod), Intercam(ntimes, alpha))
  }else if (corst == "Ar1") {
    RR = kronecker(SinEstructura(nperiod), Ar1(ntimes, alpha))
  }else{RR = kronecker(SinEstructura(nperiod), SinEstructura(ntimes)) }
  ## Periodo
  if(is.null(betas_p)){
    p_eff=rnorm(P-1)
  }else{p_eff = betas_p}
  ### Tratamiento
  if(is.null(betas_T)){
    time_effect=rnorm(L-1)
  }else{time_effect = betas_T}
  ## Secuencia
  periodo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                    kronecker(matrix(1:P, ncol=1, nrow=P), 
                              matrix(1, ncol=1, nrow=L)))
  
  tiempo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                   kronecker(matrix(1, ncol=1, nrow=P), 
                             matrix(1:L, ncol=1, nrow=L)))
  secuencia=kronecker(matrix(1:nseq, ncol=1, nrow = nseq), 
                      kronecker(matrix(1, ncol=1, nrow=P*nind), 
                                matrix(1, ncol=1, nrow=L)))
  id=as.numeric(gl(nind*nseq,nperiod*ntimes))
  datos=numeric(nind*nseq*nperiod*ntimes)
  df=data.frame(resp=datos, Periodo=factor(periodo),Secuencia=factor(secuencia),
                Tiempo=factor(tiempo), Sujeto=id )
  df=df[order(df$Sujeto,df$Periodo, df$Tiempo), ]
  ### Estructura del tratamiento
  
  df["Tratamiento"]=0
  if(disenno=="2x2"){
    ## AB, BA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else if(disenno =="PE") {
    ## ABB, BAA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else{
    ## ABA, BAB
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1 
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==3] =1
  }
  ### Estructura del carry-over
  df["Carry"]=0
  if(disenno=="2x2"){
    ## AB, BA
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==2] =-1
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==2] =1
  }else if(disenno =="PE") {
    ## ABB, BAA
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==2] =-1
    
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==2] =1
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==3] =-1
  }else{
    ## ABA, BAB
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==2] =-1
    
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==2] =1 
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==3] =-1
  }
  XX = model.matrix(lm(resp~factor(Periodo)+ factor(Tratamiento)+factor(Tiempo)+Carry, data=df))
  beta_total = c(intercepto, p_eff, tratamiento, time_effect, carry)
  df["media"]= XX%*%beta_total
  
  for(i in 1:(nind*nseq)){
    df["resp"][df["Sujeto"]==i] = rmvnorm(1, df["media"][df["Sujeto"]==i], RR)
  }
  return(list(datos=df, corr=RR))
}


### Simular binomiales ###
### Basado en 
# https://cran.r-project.org/web/packages/SimCorMultRes/vignettes/SimCorMultRes.html
####################



Sim_Bin_Kron <- function(nperiod, ntimes, nseq, nind, corst =c("Exch", "Ar1", "Unst"), alpha=0.5,
                         betas_p = NULL, betas_T = NULL,tratamiento=1, carry=0.5,
                         disenno= c("2x2", "PE", "SB"), intercepto = 2){
  P = nperiod
  L = ntimes
  if(corst == "Exch"){
    RR = kronecker(SinEstructura(nperiod), Intercam(ntimes, alpha))
  }else if (corst == "Ar1") {
    RR = kronecker(SinEstructura(nperiod), Ar1(ntimes, alpha))
  }else{RR = kronecker(SinEstructura(nperiod), SinEstructura(ntimes)) }
  ## Periodo
  if(is.null(betas_p)){
    p_eff=abs(rnorm(P-1,sd = 0.1))
  }else{p_eff = betas_p}
  ### Tratamiento
  if(is.null(betas_T)){
    time_effect=rnorm(L-1)
  }else{time_effect = betas_T}
  ## Secuencia
  periodo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                    kronecker(matrix(1:P, ncol=1, nrow=P), 
                              matrix(1, ncol=1, nrow=L)))
  
  tiempo=kronecker(matrix(1, ncol=1, nrow = nseq*nind), 
                   kronecker(matrix(1, ncol=1, nrow=P), 
                             matrix(1:L, ncol=1, nrow=L)))
  secuencia=kronecker(matrix(1:nseq, ncol=1, nrow = nseq), 
                      kronecker(matrix(1, ncol=1, nrow=P*nind), 
                                matrix(1, ncol=1, nrow=L)))
  id=as.numeric(gl(nind*nseq,nperiod*ntimes))
  datos=numeric(nind*nseq*nperiod*ntimes)
  df=data.frame(resp=datos, Periodo=factor(periodo),Secuencia=factor(secuencia),
                Tiempo=factor(tiempo), Sujeto=id )
  df=df[order(df$Sujeto,df$Periodo, df$Tiempo), ]
  ### Estructura del tratamiento
  
  df["Tratamiento"]=0
  if(disenno=="2x2"){
    ## AB, BA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else if(disenno =="PE") {
    ## ABB, BAA
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1
  }else{
    ## ABA, BAB
    df["Tratamiento"][df["Secuencia"]==1 & df["Periodo"]==2] =1
    
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==1] =1 
    df["Tratamiento"][df["Secuencia"]==2 & df["Periodo"]==3] =1
  }
  
  df["Carry"]=0
  if(disenno=="2x2"){
    ## AB, BA
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==2] =-1
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==2] =1
  }else if(disenno =="PE") {
    ## ABB, BAA
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==2] =-1
    
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==2] =1
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==3] =-1
  }else{
    ## ABA, BAB
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==2] =-1
    
    df["Carry"][df["Secuencia"]==1 & df["Periodo"]==3] =1
    
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==2] =1 
    df["Carry"][df["Secuencia"]==2 & df["Periodo"]==3] =-1
  }
  XX = model.matrix(lm(resp~Periodo+Tratamiento+Tiempo+Carry, data=df))
  beta_total = c(intercepto, p_eff, tratamiento, time_effect, carry)
  df["media"]= XX%*%beta_total
  form <- formula(lm(`(Intercept)`~., data=as.data.frame(XX)))
  df1 <- rbin(clsize = nperiod*ntimes,intercepts = intercepto, betas=beta_total[-1],
              xformula =form[c(1,3)],
              xdata= XX[,-1],
              cor.matrix = RR, link="logit")
  df["resp"] <- df1$simdata$y  
  return(list(datos=df, corr=RR))
}


obtalpha <- function(residu, datos, tipo=c("Ar1", "Exch")){
  if(tipo=="Ar1"){
    K1 = sum(table(datos$Per_id)-1)
    n = length(table(datos$Per_id))
    suma=0
    for(i in 1:n){
      residu_temp = residu[datos$Per_id==i]
      n_temp =length(residu_temp)
      suma = suma + sum(residu_temp[-n_temp]*residu_temp[-1])
    }
    alpha = suma/((K1-pp)*phi)
  }else if(tipo=="Exch"){
    K1 =sum((table(datos$Per_id)-1)*(table(datos$Per_id)))
    n = length(table(datos$Per_id))
    suma=0
    for(i in 1:n){
      residu_temp = residu[datos$Per_id==i]
      a_temp = outer(residu_temp, residu_temp)
      suma = suma + sum(a_temp[lower.tri(a_temp)])
    }
    alpha = suma/((K1-pp)*phi)
  }
  return(alpha)
}


############################
## obtener Psi #############

obtPsi <- function(residu, datos, Ralpha){
  datos["residu"] <- residu
  PP <- length(table(datos$Periodo))
  LL <- max(table(datos$Per_id))
  n_suj <- length(table(datos$Sujeto))
  Psi <- matrix(0, PP, PP)
  ### las medias por periodo
  r_media <- matrix(0, PP, LL)
  for(ii in 1:PP){
    media_temp = rep(0, LL)
    datos_temp = datos[datos$Periodo==ii,]
    for(jj in 1:n_suj){
      media_temp = media_temp + datos_temp[datos_temp$Sujeto==jj, "residu"]
    }
    r_media[ii,] <- media_temp/(n_suj)
  }
  ###### cada Psi
  for(ii in 1:PP){
    for(jj in 1:PP){
      suma_temp = 0
      for( kk in 1:n_suj){
        datos_temp1 = datos[datos$Periodo==ii,]
        datos_temp2 = datos[datos$Periodo==jj,]
        residu1 = datos_temp1[datos_temp1$Sujeto==kk, "residu"]
        residu2 = datos_temp2[datos_temp2$Sujeto==kk, "residu"]
        AAA = solve(Ralpha) %*%((residu1- r_media[ii,])%*% t((residu2- r_media[jj,])))
        suma_temp  = suma_temp  + sum(diag(AAA))
      }
      Psi[ii,jj] = suma_temp /n_suj
    }
  }
  a=Psi
  return(list(Psi=(diag(1/sqrt(diag(a))))%*% a %*% (diag(1/sqrt(diag(a)))), Ra = Ralpha, Psi1=Psi))
}


repeticion = 1
aaa = date()
while(repeticion < 10000){
  ii = sample(nind,1)
  jj = sample(alpha, 1)
  kk = sample(tratamiento,1)
  ll = sample(Matriz_sim, 1)
  mm = sample(ntimes, 1)
  cc = sample(carry,1)
  simula <- Sim_Bin_Kron(nperiod = 3, ntimes = mm, nseq = 2, nind = ii, alpha = jj, 
                         betas_p = NULL, betas_T = rep(0, mm-1), tratamiento = kk,
                         disenno = "SB", intercepto = 0.1, corst = ll, carry=cc)
  datos = simula$datos
  datos["Per_id"]=as.numeric(
    as.factor(paste(datos$Sujeto, datos$Periodo)))
  aaaa= list(param=c(ii,jj,kk,ll,mm,cc))
  save(aaaa, datos, file=file.path(getwd(), "Param_binom.RData"))
  formula = resp ~ factor(Periodo)+ Tratamiento+ Carry
  
  
  
  ### modelo 1--- > Independence -->m1
  ### modelo 2 ---> Unstructured -->m2
  ### Modelo 3 ---> Exchanegable -->m3
  ### Modelo 4 ---> AR1          -->m4
  ### Modelo 5 ---> Kron- Exc    -->m5
  ### Modelo 6 ---> Kron - Ar1  -->m6
  
  mod1 = gee(formula, family= binomial,
             data=datos, id=Per_id)
  
  mod2 = gee(formula, family= binomial,
             data=datos, id=Sujeto)
  
  mod3 = gee(formula, family= binomial,
             data=datos, id=Sujeto, corstr = "exchangeable")
  
  mod4 = gee(formula, family= binomial,
             data=datos, id=Per_id, corstr = "AR-M")
  
  ## El Exch
  init=gee(formula, family= binomial,
           data=datos, id=Sujeto)
  pp <- length(init$coefficients)
  residu <- init$residuals/sqrt(init$fitted.values-init$fitted.values^2)
  #residu <- init$residuals
  phi <- sum(residu^2)/(length(residu)-pp)
  
  
  Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Exch"))
  matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
  RR <- kronecker(matrices$Psi, matrices$Ra)
  if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
    RR = diag(1,nrow(RR))
    beep(7)
  }
  beta_init <- init$coefficients
  n_iter = 4
  diferencia <- numeric(n_iter)
  for(iter in 1:n_iter){
    modelo = gee(formula, family= binomial,
                 data=datos, id=Sujeto, corstr = "fixed",
                 R = RR, b = beta_init, maxiter = 1, tol=100)
    diferencia[iter] = sum((beta_init-modelo$coefficients)^2)
    beta_init = modelo$coefficients
    residu <- modelo$residuals/sqrt(modelo$fitted.values-modelo$fitted.values^2)
    #residu <- modelo$residuals
    phi <- sum(residu^2)/(length(residu)-pp)
    Ralpha = Intercam(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Exch"))
    matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
    RR <- kronecker(matrices$Psi, matrices$Ra)
    if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
      RR = diag(1,nrow(RR))
      beep(7)
    }
  }
  
  mod5 = modelo
  
  
  ## El AR 1
  init=gee(formula, family= binomial,
           data=datos, id=Sujeto)
  pp <- length(init$coefficients)
  residu <- init$residuals/sqrt(init$fitted.values-init$fitted.values^2)
  #residu <- init$residuals
  phi <- sum(residu^2)/(length(residu)-pp)
  
  Ralpha = Ar1(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Ar1"))
  matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
  RR <- kronecker(matrices$Psi, matrices$Ra)
  if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
    RR = diag(1,nrow(RR))
    beep(7)
  }
  beta_init <- init$coefficients
  n_iter = 4
  diferencia <- numeric(n_iter)
  for(iter in 1:n_iter){
    modelo = gee(formula, family= binomial,
                 data=datos, id=Sujeto, corstr = "fixed",
                 R = RR, b = beta_init, maxiter = 1, tol=100)
    diferencia[iter] = sum((beta_init-modelo$coefficients)^2)
    beta_init = modelo$coefficients
    residu <- modelo$residuals/sqrt(modelo$fitted.values-modelo$fitted.values^2)
    #residu <- modelo$residuals
    phi <- sum(residu^2)/(length(residu)-pp)
    Ralpha = Ar1(max(table(datos$Per_id)), obtalpha(residu, datos, tipo="Ar1"))
    matrices <- obtPsi(residu/sqrt(phi), datos, Ralpha )
    RR <- kronecker(matrices$Psi, matrices$Ra)
    if(is.complex(eigen(RR)$values) | min(eigen(RR)$values)<0){
      RR = diag(1,nrow(RR))
      beep(7)
    }
  }
  mod6 = modelo
  
  
  QIC=numeric(6)
  
  QIC[1]<--2*sum(mod1$y * log(mod1$fitted.values/(1-mod1$fitted.values))+log(1-mod1$fitted.values))+
    2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod1$naive.variance))
  QIC[2]<--2*sum(mod2$y * log(mod2$fitted.values/(1-mod2$fitted.values))+log(1-mod2$fitted.values))+
    2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod2$robust.variance))
  QIC[3]<--2*sum(mod3$y * log(mod3$fitted.values/(1-mod3$fitted.values))+log(1-mod3$fitted.values))+
    2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod3$robust.variance))
  QIC[4]<--2*sum(mod4$y * log(mod4$fitted.values/(1-mod4$fitted.values))+log(1-mod4$fitted.values))+
    2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod4$robust.variance))
  QIC[5]<--2*sum(mod5$y * log(mod5$fitted.values/(1-mod5$fitted.values))+log(1-mod5$fitted.values))+
    2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod5$robust.variance))
  QIC[6]<--2*sum(mod6$y * log(mod6$fitted.values/(1-mod6$fitted.values))+log(1-mod6$fitted.values))+
    2*sum(diag(ginv(as.matrix(mod1$robust.variance))%*%mod6$robust.variance))
  
  
  modelos= c(modelos, c("mod1", "mod2", "mod3", "mod4", "mod5", "mod6"))
  QIC_obt = c(QIC_obt, QIC)
  alphas = c(alphas, rep(jj, 6))
  tratam = c(tratam, rep(kk, 6))
  carryB = c(carryB, rep(cc, 6))
  indiv = c(indiv, rep(ii,6))
  
  a1 = summary(mod1)$coefficients
  a2 = summary(mod2)$coefficients
  a3 = summary(mod3)$coefficients
  a4 = summary(mod4)$coefficients
  a5 = summary(mod5)$coefficients
  a6 = summary(mod6)$coefficients
  estimador = cbind( a1[nrow(a1)-1,], a2[nrow(a2)-1,], a3[nrow(a3)-1,],
                     a4[nrow(a4)-1,],a5[nrow(a5)-1,],a6[nrow(a6)-1,])
  
  estim_t = c(estim_t, estimador[1,])
  p_valor_t = c(p_valor_t, 1-pnorm(abs(estimador[5,])))
  rmse_t = c(rmse_t, estimador[4,])
  estimador = cbind( a1[nrow(a1),], a2[nrow(a2),], a3[nrow(a3),],
                     a4[nrow(a4),],a5[nrow(a5),],a6[nrow(a6),])
  
  estim_c = c(estim_c, estimador[1,])
  p_valor_c = c(p_valor_c, 1-pnorm(abs(estimador[5,])))
  rmse_c = c(rmse_c, estimador[4,])
  mat_sim = c(mat_sim, rep(ll,6))
  times = c(times, rep(mm,6))
  mat_adj = c(mat_adj, c("Ind", "Uns", "Exch", "Ar1", "Kron-Exch", "Kron-Ar1"))
  repet = c(repet, rep(repeticion,6))
  repeticion = repeticion+1
  Resul_Normal = data.frame(modelos, QIC_obt ,alphas,tratam,carryB, indiv,estim_t , times,p_valor_t,rmse_t,
                            estim_c , p_valor_c,rmse_c,mat_sim ,mat_adj,repet)  
  save(Resul_Normal, file=file.path(getwd(), "Sim_2_arti_Binom.RData"))
  
}
